DAYMARK FINAL SETUP

1) Supabase SQL Editor: run daymark_permissions.sql once.
2) Supabase Edge Functions > schedule-reminder > Code:
   replace index.ts with schedule-reminder-index.ts and deploy.
3) Confirm Edge Function secrets:
   ONESIGNAL_REST_API_KEY
   ONESIGNAL_APP_ID
4) GitHub Daymark repo: upload these files to the repo root:
   index.html
   manifest.json
   OneSignalSDKWorker.js
   icon-192.png
   icon-512.png
5) Render Static Site:
   Build Command: blank
   Publish Directory: .
   Deploy latest commit.
6) iPhone Safari: open https://daymark-3.onrender.com/
   Share > Add to Home Screen.
7) Open Daymark from the Home Screen icon.
8) Sign up or sign in.
9) Settings > Enable Notifications > Allow.

The OneSignal REST API key must stay only in Supabase Secrets.
