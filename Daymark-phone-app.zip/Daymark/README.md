# Daymark

Daymark is a clean local reminder app for iPhone and Android. It includes:

- Home calendar with reminder markers
- Create/edit/delete reminders
- Native date and time pickers
- Scheduled local phone notifications
- Notification permission prompt on first launch
- Persistent reminders and settings
- Multiple app color themes
- Dark appearance, sound, vibration, and week-start preferences

## Run

Requirements: Node.js 22.13+ for Expo SDK 57.

```bash
npm install
npx expo start
```

For an installable native development build:

```bash
npx expo prebuild
npx expo run:android
# or, on macOS with Xcode:
npx expo run:ios
```

Local scheduled notifications are handled with `expo-notifications`. Android exact-time reminders use `android.permission.SCHEDULE_EXACT_ALARM` in `app.json`.

## Notification behavior

When a reminder fires, the phone notification says:

**Daymark**

**Today — <your reminder>**

The app stores the scheduled notification ID so editing or deleting a reminder cancels the old scheduled notification correctly.
