import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as Notifications from 'expo-notifications';

const STORAGE_REMINDERS = '@daymark/reminders';
const STORAGE_SETTINGS = '@daymark/settings';

const THEMES = {
  ocean: { name: 'Ocean', accent: '#3B82F6', accentSoft: '#DBEAFE', bg: '#F7F9FC', card: '#FFFFFF', text: '#121826', sub: '#667085', border: '#E6EAF0' },
  violet: { name: 'Violet', accent: '#7C3AED', accentSoft: '#EDE9FE', bg: '#FAF9FF', card: '#FFFFFF', text: '#171326', sub: '#6B6578', border: '#ECE8F3' },
  mint: { name: 'Mint', accent: '#059669', accentSoft: '#D1FAE5', bg: '#F5FBF8', card: '#FFFFFF', text: '#10221B', sub: '#64736C', border: '#E1EEE8' },
  ember: { name: 'Ember', accent: '#EA580C', accentSoft: '#FFEDD5', bg: '#FFF9F5', card: '#FFFFFF', text: '#24170F', sub: '#77695F', border: '#F1E6DE' },
  rose: { name: 'Rose', accent: '#E11D48', accentSoft: '#FFE4E6', bg: '#FFF8F9', card: '#FFFFFF', text: '#281318', sub: '#78636A', border: '#F2E4E8' },
};

const DEFAULT_SETTINGS = { theme: 'ocean', darkMode: false, sound: true, vibration: true, mondayFirst: false };

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

const pad = n => String(n).padStart(2, '0');
const dayKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const sameDay = (a, b) => dayKey(a) === dayKey(b);
const startOfDay = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const isToday = d => sameDay(d, new Date());
const monthTitle = d => d.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
const prettyDate = d => d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
const prettyTime = d => d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

function themeFor(settings) {
  const base = THEMES[settings.theme] || THEMES.ocean;
  if (!settings.darkMode) return base;
  return { ...base, bg: '#0C111B', card: '#151B26', text: '#F8FAFC', sub: '#98A2B3', border: '#293140', accentSoft: '#1D2B45' };
}

function Calendar({ month, selectedDate, reminders, onSelect, onPrev, onNext, settings, t }) {
  const y = month.getFullYear();
  const m = month.getMonth();
  const days = new Date(y, m + 1, 0).getDate();
  let first = new Date(y, m, 1).getDay();
  if (settings.mondayFirst) first = (first + 6) % 7;
  const labels = settings.mondayFirst ? ['M','T','W','T','F','S','S'] : ['S','M','T','W','T','F','S'];
  const cells = Array(first).fill(null).concat(Array.from({ length: days }, (_, i) => i + 1));
  while (cells.length % 7) cells.push(null);
  const reminderDays = new Set(reminders.filter(r => {
    const d = new Date(r.when);
    return d.getFullYear() === y && d.getMonth() === m;
  }).map(r => dayKey(new Date(r.when))));

  return <View style={[styles.calendarCard, { backgroundColor: t.card, borderColor: t.border }]}> 
    <View style={styles.calendarHeader}>
      <Pressable onPress={onPrev} style={styles.iconButton}><Text style={[styles.chevron, { color: t.text }]}>‹</Text></Pressable>
      <Text style={[styles.monthTitle, { color: t.text }]}>{monthTitle(month)}</Text>
      <Pressable onPress={onNext} style={styles.iconButton}><Text style={[styles.chevron, { color: t.text }]}>›</Text></Pressable>
    </View>
    <View style={styles.weekRow}>{labels.map((x, i) => <Text key={i} style={[styles.weekLabel, { color: t.sub }]}>{x}</Text>)}</View>
    <View style={styles.grid}>{cells.map((n, i) => {
      if (!n) return <View key={i} style={styles.dayCell}/>;
      const d = new Date(y, m, n);
      const selected = sameDay(d, selectedDate);
      const today = isToday(d);
      const marked = reminderDays.has(dayKey(d));
      return <Pressable key={i} style={styles.dayCell} onPress={() => onSelect(d)}>
        <View style={[styles.dayCircle, selected && { backgroundColor: t.accent }, today && !selected && { borderColor: t.accent, borderWidth: 1.5 }]}>
          <Text style={[styles.dayText, { color: selected ? '#FFFFFF' : t.text }]}>{n}</Text>
        </View>
        <View style={[styles.dot, { backgroundColor: marked ? t.accent : 'transparent' }]} />
      </Pressable>;
    })}</View>
  </View>;
}

function AppButton({ label, onPress, t, secondary = false, disabled = false }) {
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.primaryButton, { backgroundColor: secondary ? t.accentSoft : t.accent, opacity: disabled ? .45 : pressed ? .85 : 1 }]}>
    <Text style={[styles.primaryButtonText, { color: secondary ? t.accent : '#FFFFFF' }]}>{label}</Text>
  </Pressable>;
}

export default function App() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const t = themeFor(settings);
  const [reminders, setReminders] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [month, setMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(startOfDay(new Date()));
  const [screen, setScreen] = useState('home');
  const [permission, setPermission] = useState('unknown');
  const [text, setText] = useState('');
  const [draftDate, setDraftDate] = useState(new Date(Date.now() + 60 * 60 * 1000));
  const [showDate, setShowDate] = useState(false);
  const [showTime, setShowTime] = useState(false);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        if (Platform.OS === 'android') {
          await Notifications.setNotificationChannelAsync('reminders', {
            name: 'Reminders',
            importance: Notifications.AndroidImportance.HIGH,
            vibrationPattern: [0, 250, 120, 250],
            sound: 'default',
          });
        }
        const [savedR, savedS] = await Promise.all([AsyncStorage.getItem(STORAGE_REMINDERS), AsyncStorage.getItem(STORAGE_SETTINGS)]);
        if (savedR) setReminders(JSON.parse(savedR));
        if (savedS) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(savedS) });
        const p = await Notifications.getPermissionsAsync();
        setPermission(p.granted ? 'granted' : 'denied');
        if (!p.granted && p.canAskAgain !== false) {
          const requested = await Notifications.requestPermissionsAsync({ ios: { allowAlert: true, allowBadge: false, allowSound: true } });
          setPermission(requested.granted ? 'granted' : 'denied');
        }
      } catch (e) {
        console.warn(e);
      } finally { setLoaded(true); }
    })();
  }, []);

  useEffect(() => { if (loaded) AsyncStorage.setItem(STORAGE_REMINDERS, JSON.stringify(reminders)); }, [reminders, loaded]);
  useEffect(() => { if (loaded) AsyncStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings)); }, [settings, loaded]);

  const selectedReminders = useMemo(() => reminders.filter(r => sameDay(new Date(r.when), selectedDate)).sort((a,b) => new Date(a.when)-new Date(b.when)), [reminders, selectedDate]);
  const upcoming = useMemo(() => reminders.filter(r => new Date(r.when).getTime() >= Date.now() - 60000).sort((a,b) => new Date(a.when)-new Date(b.when)).slice(0, 4), [reminders]);

  const openNew = () => {
    setText(''); setEditingId(null);
    const now = new Date();
    const base = sameDay(selectedDate, now) ? new Date(now.getTime() + 60 * 60 * 1000) : new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), 9, 0);
    setDraftDate(base); setScreen('edit');
  };

  const openEdit = r => { setText(r.text); setDraftDate(new Date(r.when)); setEditingId(r.id); setScreen('edit'); };

  const ensurePermission = async () => {
    let p = await Notifications.getPermissionsAsync();
    if (!p.granted && p.canAskAgain !== false) p = await Notifications.requestPermissionsAsync({ ios: { allowAlert: true, allowBadge: false, allowSound: true } });
    setPermission(p.granted ? 'granted' : 'denied');
    return p.granted;
  };

  const saveReminder = async () => {
    const clean = text.trim();
    if (!clean) return Alert.alert('Add a reminder', 'Write what you want Daymark to remind you about.');
    if (draftDate.getTime() <= Date.now()) return Alert.alert('Choose a future time', 'Your reminder needs to be scheduled for a time that has not passed yet.');
    const allowed = await ensurePermission();
    if (!allowed) return Alert.alert('Notifications are off', 'Enable notifications for Daymark in your phone settings so reminders can alert you.');
    try {
      if (editingId) {
        const old = reminders.find(r => r.id === editingId);
        if (old?.notificationId) await Notifications.cancelScheduledNotificationAsync(old.notificationId).catch(() => {});
      }
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: 'Daymark',
          body: `Today — ${clean}`,
          sound: settings.sound ? 'default' : undefined,
          data: { reminderText: clean },
        },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: draftDate, channelId: Platform.OS === 'android' ? 'reminders' : undefined },
      });
      const item = { id: editingId || `${Date.now()}-${Math.random().toString(36).slice(2,7)}`, text: clean, when: draftDate.toISOString(), notificationId };
      setReminders(prev => editingId ? prev.map(x => x.id === editingId ? item : x) : [...prev, item]);
      setSelectedDate(startOfDay(draftDate)); setMonth(new Date(draftDate.getFullYear(), draftDate.getMonth(), 1)); setScreen('home');
    } catch (e) {
      Alert.alert('Couldn’t schedule reminder', e?.message || 'Please try again.');
    }
  };

  const removeReminder = async r => {
    if (r.notificationId) await Notifications.cancelScheduledNotificationAsync(r.notificationId).catch(() => {});
    setReminders(prev => prev.filter(x => x.id !== r.id));
    setScreen('home');
  };

  if (!loaded) return <SafeAreaView style={[styles.safe, { backgroundColor: t.bg }]}><StatusBar barStyle={settings.darkMode ? 'light-content' : 'dark-content'} /><View style={styles.loading}><Text style={[styles.logo, { color: t.accent }]}>Daymark</Text><Text style={{ color: t.sub }}>Getting things ready…</Text></View></SafeAreaView>;

  return <SafeAreaView style={[styles.safe, { backgroundColor: t.bg }]}>
    <StatusBar barStyle={settings.darkMode ? 'light-content' : 'dark-content'} />
    {screen === 'home' && <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.topbar}>
        <View><Text style={[styles.kicker, { color: t.accent }]}>WELCOME TO</Text><Text style={[styles.logo, { color: t.text }]}>Daymark</Text></View>
        <Pressable onPress={() => setScreen('settings')} style={[styles.settingsBtn, { backgroundColor: t.card, borderColor: t.border }]}><Text style={[styles.settingsIcon, { color: t.text }]}>⚙︎</Text></Pressable>
      </View>
      <Text style={[styles.subtitle, { color: t.sub }]}>Your days, clearly marked.</Text>
      {permission !== 'granted' && <Pressable onPress={ensurePermission} style={[styles.permissionCard, { backgroundColor: t.accentSoft }]}><Text style={[styles.permissionTitle, { color: t.accent }]}>Turn on notifications</Text><Text style={[styles.permissionText, { color: t.text }]}>Daymark needs permission to alert you at the exact date and time you choose.</Text></Pressable>}
      <Calendar month={month} selectedDate={selectedDate} reminders={reminders} onSelect={setSelectedDate} onPrev={() => setMonth(new Date(month.getFullYear(), month.getMonth()-1, 1))} onNext={() => setMonth(new Date(month.getFullYear(), month.getMonth()+1, 1))} settings={settings} t={t}/>
      <View style={styles.sectionHeader}><View><Text style={[styles.sectionTitle, { color: t.text }]}>{isToday(selectedDate) ? 'Today' : prettyDate(selectedDate)}</Text><Text style={[styles.sectionSub, { color: t.sub }]}>{selectedReminders.length ? `${selectedReminders.length} reminder${selectedReminders.length === 1 ? '' : 's'}` : 'Nothing planned yet'}</Text></View><Pressable onPress={openNew} style={[styles.newButton, { backgroundColor: t.accent }]}><Text style={styles.plus}>＋</Text><Text style={styles.newButtonText}>New</Text></Pressable></View>
      {selectedReminders.map(r => <Pressable key={r.id} onPress={() => openEdit(r)} style={[styles.reminderCard, { backgroundColor: t.card, borderColor: t.border }]}><View style={[styles.timePill, { backgroundColor: t.accentSoft }]}><Text style={[styles.timePillText, { color: t.accent }]}>{prettyTime(new Date(r.when))}</Text></View><View style={styles.reminderMain}><Text style={[styles.reminderText, { color: t.text }]} numberOfLines={2}>{r.text}</Text><Text style={[styles.tapEdit, { color: t.sub }]}>Tap to edit</Text></View><Text style={[styles.arrow, { color: t.sub }]}>›</Text></Pressable>)}
      {!selectedReminders.length && <View style={[styles.emptyCard, { backgroundColor: t.card, borderColor: t.border }]}><Text style={styles.emptyEmoji}>✦</Text><Text style={[styles.emptyTitle, { color: t.text }]}>Open space</Text><Text style={[styles.emptyText, { color: t.sub }]}>Add something you don’t want to forget.</Text></View>}
      {upcoming.length > 0 && <View style={styles.upcoming}><Text style={[styles.sectionTitle, { color: t.text }]}>Up next</Text>{upcoming.map(r => <View key={r.id} style={styles.upcomingRow}><View style={[styles.miniDot, { backgroundColor: t.accent }]}/><Text style={[styles.upcomingText, { color: t.text }]} numberOfLines={1}>{r.text}</Text><Text style={[styles.upcomingDate, { color: t.sub }]}>{prettyDate(new Date(r.when))}</Text></View>)}</View>}
      <View style={{ height: 28 }}/>
    </ScrollView>}

    {screen === 'edit' && <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
      <View style={styles.pageHeader}><Pressable onPress={() => setScreen('home')}><Text style={[styles.back, { color: t.accent }]}>‹ Back</Text></Pressable><Text style={[styles.pageTitle, { color: t.text }]}>{editingId ? 'Edit reminder' : 'New reminder'}</Text><View style={{ width: 52 }}/></View>
      <Text style={[styles.fieldLabel, { color: t.sub }]}>REMIND ME TO</Text>
      <TextInput value={text} onChangeText={setText} multiline autoFocus placeholder="e.g. Call Grandma" placeholderTextColor={t.sub} style={[styles.input, { backgroundColor: t.card, color: t.text, borderColor: t.border }]} maxLength={180}/>
      <Text style={[styles.fieldLabel, { color: t.sub }]}>WHEN</Text>
      <Pressable onPress={() => setShowDate(true)} style={[styles.pickerRow, { backgroundColor: t.card, borderColor: t.border }]}><View><Text style={[styles.pickerLabel, { color: t.sub }]}>Date</Text><Text style={[styles.pickerValue, { color: t.text }]}>{draftDate.toLocaleDateString(undefined, { weekday:'long', month:'long', day:'numeric', year:'numeric' })}</Text></View><Text style={[styles.pickerGlyph, { color: t.accent }]}>▣</Text></Pressable>
      <Pressable onPress={() => setShowTime(true)} style={[styles.pickerRow, { backgroundColor: t.card, borderColor: t.border }]}><View><Text style={[styles.pickerLabel, { color: t.sub }]}>Time</Text><Text style={[styles.pickerValue, { color: t.text }]}>{prettyTime(draftDate)}</Text></View><Text style={[styles.pickerGlyph, { color: t.accent }]}>◷</Text></Pressable>
      <View style={[styles.preview, { backgroundColor: t.accentSoft }]}><Text style={[styles.previewLabel, { color: t.accent }]}>NOTIFICATION PREVIEW</Text><Text style={[styles.previewTitle, { color: t.text }]}>Daymark</Text><Text style={[styles.previewBody, { color: t.text }]}>Today — {text.trim() || 'Your reminder'}</Text></View>
      <AppButton label={editingId ? 'Save changes' : 'Add reminder'} onPress={saveReminder} t={t} disabled={!text.trim()}/>
      {editingId && <Pressable onPress={() => Alert.alert('Delete reminder?', 'This also cancels its scheduled notification.', [{ text:'Cancel', style:'cancel' }, { text:'Delete', style:'destructive', onPress:() => removeReminder(reminders.find(r => r.id === editingId)) }])} style={styles.deleteButton}><Text style={styles.deleteText}>Delete reminder</Text></Pressable>}
      {showDate && <DateTimePicker value={draftDate} mode="date" minimumDate={new Date()} onChange={(e, d) => { setShowDate(Platform.OS === 'ios'); if (d) setDraftDate(new Date(d.getFullYear(), d.getMonth(), d.getDate(), draftDate.getHours(), draftDate.getMinutes())); }} />}
      {showTime && <DateTimePicker value={draftDate} mode="time" onChange={(e, d) => { setShowTime(Platform.OS === 'ios'); if (d) setDraftDate(new Date(draftDate.getFullYear(), draftDate.getMonth(), draftDate.getDate(), d.getHours(), d.getMinutes())); }} />}
      {(showDate || showTime) && Platform.OS === 'ios' && <AppButton label="Done" onPress={() => { setShowDate(false); setShowTime(false); }} t={t} secondary/>}
    </ScrollView>}

    {screen === 'settings' && <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.pageHeader}><Pressable onPress={() => setScreen('home')}><Text style={[styles.back, { color: t.accent }]}>‹ Back</Text></Pressable><Text style={[styles.pageTitle, { color: t.text }]}>Settings</Text><View style={{ width: 52 }}/></View>
      <Text style={[styles.fieldLabel, { color: t.sub }]}>COLOR THEME</Text>
      <View style={[styles.settingsCard, { backgroundColor: t.card, borderColor: t.border }]}>{Object.entries(THEMES).map(([key, th], index) => <Pressable key={key} onPress={() => setSettings(s => ({ ...s, theme: key }))} style={[styles.themeRow, index < Object.keys(THEMES).length - 1 && { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: t.border }]}><View style={[styles.themeSwatch, { backgroundColor: th.accent }]}/><Text style={[styles.settingText, { color: t.text }]}>{th.name}</Text><Text style={[styles.check, { color: t.accent }]}>{settings.theme === key ? '✓' : ''}</Text></Pressable>)}</View>
      <Text style={[styles.fieldLabel, { color: t.sub }]}>PREFERENCES</Text>
      <View style={[styles.settingsCard, { backgroundColor: t.card, borderColor: t.border }]}>
        <SettingSwitch title="Dark appearance" subtitle="Use Daymark’s dark color layout" value={settings.darkMode} onValueChange={v => setSettings(s => ({ ...s, darkMode:v }))} t={t}/>
        <SettingSwitch title="Notification sound" subtitle="Play a sound with reminders" value={settings.sound} onValueChange={v => setSettings(s => ({ ...s, sound:v }))} t={t}/>
        <SettingSwitch title="Vibration" subtitle="Allow reminder vibration on Android" value={settings.vibration} onValueChange={async v => { setSettings(s => ({ ...s, vibration:v })); if (Platform.OS === 'android') await Notifications.setNotificationChannelAsync('reminders', { name:'Reminders', importance:Notifications.AndroidImportance.HIGH, vibrationPattern:v ? [0,250,120,250] : null, sound: settings.sound ? 'default' : null }); }} t={t}/>
        <SettingSwitch title="Week starts Monday" subtitle="Change the calendar’s first day" value={settings.mondayFirst} onValueChange={v => setSettings(s => ({ ...s, mondayFirst:v }))} t={t} last/>
      </View>
      <Text style={[styles.fieldLabel, { color: t.sub }]}>NOTIFICATIONS</Text>
      <View style={[styles.settingsCard, { backgroundColor: t.card, borderColor: t.border }]}><View style={styles.infoRow}><View style={{ flex:1 }}><Text style={[styles.settingText, { color:t.text }]}>Permission</Text><Text style={[styles.settingSub, { color:t.sub }]}>{permission === 'granted' ? 'Allowed — reminders can alert you.' : 'Not allowed — tap to request access.'}</Text></View><Pressable onPress={ensurePermission}><Text style={[styles.linkText, { color:t.accent }]}>{permission === 'granted' ? 'Allowed' : 'Enable'}</Text></Pressable></View></View>
      <Text style={[styles.version, { color:t.sub }]}>Daymark 1.0.0</Text>
    </ScrollView>}
  </SafeAreaView>;
}

function SettingSwitch({ title, subtitle, value, onValueChange, t, last=false }) {
  return <View style={[styles.switchRow, !last && { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor:t.border }]}><View style={{ flex:1, paddingRight:14 }}><Text style={[styles.settingText, { color:t.text }]}>{title}</Text><Text style={[styles.settingSub, { color:t.sub }]}>{subtitle}</Text></View><Switch value={value} onValueChange={onValueChange} trackColor={{ false:'#D0D5DD', true:t.accent }} thumbColor="#FFFFFF"/></View>;
}

const styles = StyleSheet.create({
  safe:{ flex:1 }, container:{ paddingHorizontal:20, paddingTop:16 }, loading:{ flex:1, alignItems:'center', justifyContent:'center', gap:8 },
  topbar:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between' }, kicker:{ fontSize:12, fontWeight:'800', letterSpacing:1.7 }, logo:{ fontSize:34, fontWeight:'800', letterSpacing:-1.1 }, subtitle:{ marginTop:3, fontSize:16, marginBottom:20 },
  settingsBtn:{ width:44, height:44, borderRadius:14, alignItems:'center', justifyContent:'center', borderWidth:1 }, settingsIcon:{ fontSize:22, fontWeight:'600' },
  permissionCard:{ borderRadius:18, padding:16, marginBottom:16 }, permissionTitle:{ fontSize:15, fontWeight:'800', marginBottom:4 }, permissionText:{ fontSize:13, lineHeight:19 },
  calendarCard:{ borderWidth:1, borderRadius:24, padding:14, shadowColor:'#000', shadowOpacity:.035, shadowRadius:12, shadowOffset:{width:0,height:5} }, calendarHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:10 }, monthTitle:{ fontSize:18, fontWeight:'800' }, iconButton:{ width:38,height:38,alignItems:'center',justifyContent:'center' }, chevron:{ fontSize:32, lineHeight:34 }, weekRow:{ flexDirection:'row' }, weekLabel:{ width:'14.285%', textAlign:'center', fontSize:12, fontWeight:'700', paddingVertical:8 }, grid:{ flexDirection:'row', flexWrap:'wrap' }, dayCell:{ width:'14.285%', height:48, alignItems:'center', justifyContent:'center' }, dayCircle:{ width:34,height:34,borderRadius:17,alignItems:'center',justifyContent:'center' }, dayText:{ fontSize:14, fontWeight:'650' }, dot:{ width:4,height:4,borderRadius:2,marginTop:2 },
  sectionHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginTop:24, marginBottom:12 }, sectionTitle:{ fontSize:20, fontWeight:'800', letterSpacing:-.35 }, sectionSub:{ fontSize:13, marginTop:2 }, newButton:{ flexDirection:'row', alignItems:'center', borderRadius:16, paddingHorizontal:15, height:44 }, plus:{ color:'#fff', fontSize:22, marginRight:4, marginTop:-1 }, newButtonText:{ color:'#fff', fontSize:15, fontWeight:'800' },
  reminderCard:{ borderWidth:1, borderRadius:18, padding:13, flexDirection:'row', alignItems:'center', marginBottom:10 }, timePill:{ borderRadius:12, paddingHorizontal:10, paddingVertical:8, minWidth:76, alignItems:'center' }, timePillText:{ fontWeight:'800', fontSize:13 }, reminderMain:{ flex:1, paddingHorizontal:12 }, reminderText:{ fontSize:15, fontWeight:'700', lineHeight:20 }, tapEdit:{ fontSize:11, marginTop:3 }, arrow:{ fontSize:28 },
  emptyCard:{ borderWidth:1, borderStyle:'dashed', borderRadius:20, padding:25, alignItems:'center' }, emptyEmoji:{ fontSize:25, marginBottom:7 }, emptyTitle:{ fontSize:16, fontWeight:'800' }, emptyText:{ fontSize:13, marginTop:4 }, upcoming:{ marginTop:24 }, upcomingRow:{ flexDirection:'row', alignItems:'center', paddingVertical:10 }, miniDot:{ width:7,height:7,borderRadius:4,marginRight:10 }, upcomingText:{ flex:1, fontSize:14, fontWeight:'650' }, upcomingDate:{ fontSize:12, marginLeft:10 },
  pageHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:26 }, back:{ fontSize:16, fontWeight:'700', width:52 }, pageTitle:{ fontSize:18, fontWeight:'800' }, fieldLabel:{ fontSize:11, fontWeight:'800', letterSpacing:1.3, marginBottom:8, marginTop:12 },
  input:{ minHeight:124, borderRadius:20, borderWidth:1, padding:16, fontSize:18, fontWeight:'650', textAlignVertical:'top' }, pickerRow:{ borderRadius:18,borderWidth:1,padding:15,marginBottom:10,flexDirection:'row',alignItems:'center',justifyContent:'space-between' }, pickerLabel:{ fontSize:12, marginBottom:3 }, pickerValue:{ fontSize:15, fontWeight:'700' }, pickerGlyph:{ fontSize:23 }, preview:{ borderRadius:18, padding:16, marginTop:12, marginBottom:20 }, previewLabel:{ fontSize:10,fontWeight:'800',letterSpacing:1.2,marginBottom:9 }, previewTitle:{ fontSize:13,fontWeight:'800',marginBottom:3 }, previewBody:{ fontSize:15,lineHeight:20 },
  primaryButton:{ minHeight:54,borderRadius:17,alignItems:'center',justifyContent:'center',marginBottom:10 }, primaryButtonText:{ fontSize:16,fontWeight:'800' }, deleteButton:{ alignItems:'center',padding:16 }, deleteText:{ color:'#DC2626',fontSize:15,fontWeight:'700' },
  settingsCard:{ borderWidth:1,borderRadius:20,overflow:'hidden',marginBottom:20 }, themeRow:{ minHeight:55,flexDirection:'row',alignItems:'center',paddingHorizontal:15 }, themeSwatch:{ width:22,height:22,borderRadius:11,marginRight:12 }, check:{ width:26,textAlign:'right',fontSize:18,fontWeight:'900' }, switchRow:{ minHeight:72,flexDirection:'row',alignItems:'center',paddingHorizontal:15,paddingVertical:10 }, settingText:{ flex:1,fontSize:15,fontWeight:'700' }, settingSub:{ fontSize:12,marginTop:3,lineHeight:16 }, infoRow:{ padding:15,flexDirection:'row',alignItems:'center' }, linkText:{ fontSize:13,fontWeight:'800' }, version:{ textAlign:'center',fontSize:12,marginVertical:12 },
});
